﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RDF.Arcana.API.Migrations
{
    /// <inheritdoc />
    public partial class initialpost : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateSequence(
                name: "arcana_hilo_sequence",
                incrementBy: 10);

            migrationBuilder.CreateTable(
                name: "Address",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false),
                    HouseNumber = table.Column<string>(type: "text", nullable: true),
                    StreetName = table.Column<string>(type: "text", nullable: true),
                    Barangay = table.Column<string>(type: "text", nullable: true),
                    City = table.Column<string>(type: "text", nullable: true),
                    Province = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BusinessAddress",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false),
                    HouseNumber = table.Column<string>(type: "text", nullable: true),
                    StreetName = table.Column<string>(type: "text", nullable: true),
                    Barangay = table.Column<string>(type: "text", nullable: true),
                    City = table.Column<string>(type: "text", nullable: true),
                    Province = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BusinessAddress", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Clusters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ClusterType = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clusters", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FixedDiscounts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false),
                    DiscountPercentage = table.Column<decimal>(type: "numeric(8,2)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FixedDiscounts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "VariableDiscounts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    MinimumAmount = table.Column<decimal>(type: "numeric(18,6)", nullable: false),
                    MaximumAmount = table.Column<decimal>(type: "numeric(18,6)", nullable: false),
                    MinimumPercentage = table.Column<decimal>(type: "numeric(8,2)", nullable: false),
                    MaximumPercentage = table.Column<decimal>(type: "numeric(8,2)", nullable: false),
                    IsSubjectToApproval = table.Column<bool>(type: "boolean", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VariableDiscounts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Approval",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RequestId = table.Column<int>(type: "integer", nullable: false),
                    ApproverId = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: true),
                    Reason = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Approval", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Approvers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    ModuleName = table.Column<string>(type: "text", nullable: true),
                    Level = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Approvers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BookingCoverages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BookingCoverage = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookingCoverages", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CdoClusters",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ClusterId = table.Column<int>(type: "integer", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    CreatesAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdateAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CdoClusters", x => x.Id);
                    table.ForeignKey(
                        name: "FK_CdoClusters_Clusters_ClusterId",
                        column: x => x.ClusterId,
                        principalTable: "Clusters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ClientDocuments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ClientId = table.Column<int>(type: "integer", nullable: false),
                    DocumentType = table.Column<string>(type: "text", nullable: true),
                    DocumentPath = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientDocuments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ClientModeOfPayments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ClientId = table.Column<int>(type: "integer", nullable: false),
                    ModeOfPaymentId = table.Column<int>(type: "integer", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientModeOfPayments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Clients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false),
                    Fullname = table.Column<string>(type: "text", nullable: true),
                    OwnersAddressId = table.Column<int>(type: "integer", nullable: false),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    EmailAddress = table.Column<string>(type: "text", nullable: true),
                    BusinessName = table.Column<string>(type: "text", nullable: true),
                    TinNumber = table.Column<string>(type: "text", nullable: true),
                    RepresentativeName = table.Column<string>(type: "text", nullable: true),
                    RepresentativePosition = table.Column<string>(type: "text", nullable: true),
                    BusinessAddressId = table.Column<int>(type: "integer", nullable: true),
                    ClusterId = table.Column<int>(type: "integer", nullable: true),
                    PriceModeId = table.Column<int>(type: "integer", nullable: true),
                    Freezer = table.Column<bool>(type: "boolean", nullable: false),
                    CustomerType = table.Column<string>(type: "text", nullable: true),
                    Origin = table.Column<string>(type: "text", nullable: true),
                    TermDays = table.Column<int>(type: "integer", nullable: true),
                    DiscountId = table.Column<int>(type: "integer", nullable: true),
                    StoreTypeId = table.Column<int>(type: "integer", nullable: true),
                    RegistrationStatus = table.Column<string>(type: "text", nullable: true),
                    Terms = table.Column<int>(type: "integer", nullable: true),
                    DirectDelivery = table.Column<bool>(type: "boolean", nullable: true),
                    BookingCoverageId = table.Column<int>(type: "integer", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    Longitude = table.Column<string>(type: "text", nullable: true),
                    Latitude = table.Column<string>(type: "text", nullable: true),
                    RequestId = table.Column<int>(type: "integer", nullable: true),
                    FixedDiscountId = table.Column<int>(type: "integer", nullable: true),
                    VariableDiscount = table.Column<bool>(type: "boolean", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clients", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Clients_Address_OwnersAddressId",
                        column: x => x.OwnersAddressId,
                        principalTable: "Address",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_Clients_BookingCoverages_BookingCoverageId",
                        column: x => x.BookingCoverageId,
                        principalTable: "BookingCoverages",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Clients_BusinessAddress_BusinessAddressId",
                        column: x => x.BusinessAddressId,
                        principalTable: "BusinessAddress",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Clients_Clusters_ClusterId",
                        column: x => x.ClusterId,
                        principalTable: "Clusters",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Clients_FixedDiscounts_FixedDiscountId",
                        column: x => x.FixedDiscountId,
                        principalTable: "FixedDiscounts",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Companies",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    CompanyName = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Companies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    DepartmentName = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Discounts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    DiscountType = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdateAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Discounts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Expenses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ClientId = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    RequestId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Expenses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Expenses_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ExpensesRequests",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ExpensesId = table.Column<int>(type: "integer", nullable: false),
                    OtherExpenseId = table.Column<int>(type: "integer", nullable: false),
                    Amount = table.Column<decimal>(type: "numeric", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ExpensesRequests", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ExpensesRequests_Expenses_ExpensesId",
                        column: x => x.ExpensesId,
                        principalTable: "Expenses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "FreebieItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FreebieRequestId = table.Column<int>(type: "integer", nullable: false),
                    ItemId = table.Column<int>(type: "integer", nullable: false),
                    Quantity = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FreebieItems", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FreebieRequests",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false),
                    ClientId = table.Column<int>(type: "integer", nullable: false),
                    RequestId = table.Column<int>(type: "integer", nullable: true),
                    Status = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    IsDelivered = table.Column<bool>(type: "boolean", nullable: false),
                    PhotoProofPath = table.Column<string>(type: "text", nullable: true),
                    ESignaturePath = table.Column<string>(type: "text", nullable: true),
                    RequestedBy = table.Column<int>(type: "integer", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FreebieRequests", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FreebieRequests_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ItemPriceChanges",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PriceModeItemId = table.Column<int>(type: "integer", nullable: false),
                    Price = table.Column<decimal>(type: "numeric", nullable: false),
                    EffectivityDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ItemPriceChanges", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Items",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ItemCode = table.Column<string>(type: "text", nullable: true),
                    ItemDescription = table.Column<string>(type: "text", nullable: true),
                    UomId = table.Column<int>(type: "integer", nullable: false),
                    ProductSubCategoryId = table.Column<int>(type: "integer", nullable: false),
                    MeatTypeId = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Items", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ListingFeeItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ListingFeeId = table.Column<int>(type: "integer", nullable: false),
                    ItemId = table.Column<int>(type: "integer", nullable: false),
                    Sku = table.Column<int>(type: "integer", nullable: false),
                    UnitCost = table.Column<decimal>(type: "numeric", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ListingFeeItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ListingFeeItems_Items_ItemId",
                        column: x => x.ItemId,
                        principalTable: "Items",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ListingFees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ClientId = table.Column<int>(type: "integer", nullable: false),
                    RequestId = table.Column<int>(type: "integer", nullable: false),
                    CratedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ApprovalDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    IsDelivered = table.Column<bool>(type: "boolean", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: true),
                    RequestedBy = table.Column<int>(type: "integer", nullable: false),
                    Total = table.Column<decimal>(type: "numeric(8,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ListingFees", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ListingFees_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "Locations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    LocationName = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Locations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MeatTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    MeatTypeName = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MeatTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ModeOfPayments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Payment = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModeOfPayments", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Notifications",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserId = table.Column<int>(type: "integer", nullable: true),
                    ClusterId = table.Column<int>(type: "integer", nullable: true),
                    Status = table.Column<string>(type: "text", nullable: true),
                    IsRead = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Notifications", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "OtherExpenses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ExpenseType = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OtherExpenses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PriceMode",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    PriceModeCode = table.Column<string>(type: "text", nullable: true),
                    PriceModeDescription = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PriceMode", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PriceModeItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ItemId = table.Column<int>(type: "integer", nullable: false),
                    PriceModeId = table.Column<int>(type: "integer", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PriceModeItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PriceModeItems_Items_ItemId",
                        column: x => x.ItemId,
                        principalTable: "Items",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                    table.ForeignKey(
                        name: "FK_PriceModeItems_PriceMode_PriceModeId",
                        column: x => x.PriceModeId,
                        principalTable: "PriceMode",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "ProductCategories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ProductCategoryName = table.Column<string>(type: "text", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductCategories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductSubCategories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ProductSubCategoryName = table.Column<string>(type: "text", nullable: true),
                    ProductCategoryId = table.Column<int>(type: "integer", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductSubCategories", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ProductSubCategories_ProductCategories_ProductCategoryId",
                        column: x => x.ProductCategoryId,
                        principalTable: "ProductCategories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "RequestApprovers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RequestId = table.Column<int>(type: "integer", nullable: false),
                    ApproverId = table.Column<int>(type: "integer", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Level = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RequestApprovers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Requests",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Module = table.Column<string>(type: "text", nullable: true),
                    RequestorId = table.Column<int>(type: "integer", nullable: false),
                    CurrentApproverId = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Requests", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UpdateRequestTrails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RequestId = table.Column<int>(type: "integer", nullable: true),
                    ModuleName = table.Column<string>(type: "text", nullable: true),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedBy = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UpdateRequestTrails", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UpdateRequestTrails_Requests_RequestId",
                        column: x => x.RequestId,
                        principalTable: "Requests",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "StoreTypes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    StoreTypeName = table.Column<string>(type: "text", nullable: true),
                    CreateAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdateAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedBy = table.Column<int>(type: "integer", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StoreTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TermDays",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Days = table.Column<int>(type: "integer", nullable: false),
                    CreateAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TermDays", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TermOptions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false),
                    TermsId = table.Column<int>(type: "integer", nullable: false),
                    CreditLimit = table.Column<int>(type: "integer", nullable: true),
                    TermDaysId = table.Column<int>(type: "integer", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ClientsId = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TermOptions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TermOptions_Clients_ClientsId",
                        column: x => x.ClientsId,
                        principalTable: "Clients",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_TermOptions_TermDays_TermDaysId",
                        column: x => x.TermDaysId,
                        principalTable: "TermDays",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Terms",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    TermType = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Terms", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Uoms",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UomCode = table.Column<string>(type: "text", nullable: true),
                    UomDescription = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: false),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Uoms", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserRoles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserRoleName = table.Column<string>(type: "text", nullable: true),
                    Permissions = table.Column<string>(type: "text", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    AddedBy = table.Column<int>(type: "integer", nullable: true),
                    ModifiedBy = table.Column<string>(type: "text", nullable: true),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FullIdNo = table.Column<string>(type: "text", nullable: true),
                    Fullname = table.Column<string>(type: "text", nullable: true),
                    Username = table.Column<string>(type: "text", nullable: true),
                    Password = table.Column<string>(type: "text", nullable: true),
                    IsPasswordChanged = table.Column<bool>(type: "boolean", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsActive = table.Column<bool>(type: "boolean", nullable: false),
                    CompanyId = table.Column<int>(type: "integer", nullable: true),
                    DepartmentId = table.Column<int>(type: "integer", nullable: true),
                    LocationId = table.Column<int>(type: "integer", nullable: true),
                    UserRolesId = table.Column<int>(type: "integer", nullable: true),
                    AddedBy = table.Column<int>(type: "integer", nullable: true),
                    ProfilePicture = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Users_Companies_CompanyId",
                        column: x => x.CompanyId,
                        principalTable: "Companies",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Users_Departments_DepartmentId",
                        column: x => x.DepartmentId,
                        principalTable: "Departments",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Users_Locations_LocationId",
                        column: x => x.LocationId,
                        principalTable: "Locations",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Users_UserRoles_UserRolesId",
                        column: x => x.UserRolesId,
                        principalTable: "UserRoles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Users_Users_AddedBy",
                        column: x => x.AddedBy,
                        principalTable: "Users",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "UserRoles",
                columns: new[] { "Id", "AddedBy", "CreatedAt", "IsActive", "ModifiedBy", "Permissions", "UpdatedAt", "UserRoleName" },
                values: new object[] { 1, null, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(6992), true, null, "[\"User Management\",\"User Account\",\"User Role\",\"Company\",\"Department\",\"Location\",\"Masterlist\",\"Products\",\"Meat Type\",\"UOM\",\"Discount Type\",\"Terms\",\"Customer Registration\",\"Prospect\",\"Direct\",\"Freebies\",\"Inventory\",\"Setup\",\"Product Category\",\"Product Sub Category\",\"Unit of Measurements\",\"Store Type\",\"Discount\",\"Term Days\",\"Approval\",\"Freebie Approval\",\"Direct Approval\",\"Admin Dashboard\",\"Direct Registration\",\"Listing Fee\",\"Registration Approval\",\"Sp. Discount Approval\",\"Listing Fee Approval\",\"Business Type\",\"Registration\",\"Customer Management\",\"Product Setup\",\"Variable Discount\"]", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Admin" });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "AddedBy", "CompanyId", "CreatedAt", "DepartmentId", "FullIdNo", "Fullname", "IsActive", "IsPasswordChanged", "LocationId", "Password", "ProfilePicture", "UpdatedAt", "UserRolesId", "Username" },
                values: new object[] { 1, null, null, new DateTime(2024, 2, 8, 22, 16, 50, 455, DateTimeKind.Local).AddTicks(8383), null, null, "Admin", true, false, null, "$2a$11$zAhMb0h0I2978dTOV2RSru16DBMTEDmG5UnX0bZh.IP9P8QaU9wK2", null, new DateTime(2024, 2, 8, 22, 16, 50, 455, DateTimeKind.Local).AddTicks(8396), 1, "admin" });

            migrationBuilder.InsertData(
                table: "BookingCoverages",
                columns: new[] { "Id", "AddedBy", "BookingCoverage", "CreatedAt", "IsActive", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, 1, "F1", new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7068), true, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7068) },
                    { 2, 1, "F2", new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7072), true, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7072) },
                    { 3, 1, "F3", new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7074), true, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7074) },
                    { 4, 1, "F4", new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7075), true, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7085) },
                    { 5, 1, "F5", new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7087), true, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7087) }
                });

            migrationBuilder.InsertData(
                table: "ModeOfPayments",
                columns: new[] { "Id", "AddedBy", "CreatedAt", "IsActive", "Payment", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7166), true, "Cash", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, 1, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7170), true, "Online/Check", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "Terms",
                columns: new[] { "Id", "AddedBy", "CreatedAt", "IsActive", "TermType", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7117), true, "COD", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, 1, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7135), true, "1 Up 1 Down", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, 1, new DateTime(2024, 2, 8, 22, 16, 50, 571, DateTimeKind.Local).AddTicks(7137), true, "Credit Type", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Approval_ApproverId",
                table: "Approval",
                column: "ApproverId");

            migrationBuilder.CreateIndex(
                name: "IX_Approval_RequestId",
                table: "Approval",
                column: "RequestId");

            migrationBuilder.CreateIndex(
                name: "IX_Approvers_UserId",
                table: "Approvers",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_BookingCoverages_AddedBy",
                table: "BookingCoverages",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_CdoClusters_ClusterId",
                table: "CdoClusters",
                column: "ClusterId");

            migrationBuilder.CreateIndex(
                name: "IX_CdoClusters_UserId",
                table: "CdoClusters",
                column: "UserId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ClientDocuments_ClientId",
                table: "ClientDocuments",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientModeOfPayments_ClientId",
                table: "ClientModeOfPayments",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_ClientModeOfPayments_ModeOfPaymentId",
                table: "ClientModeOfPayments",
                column: "ModeOfPaymentId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_AddedBy",
                table: "Clients",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_BookingCoverageId",
                table: "Clients",
                column: "BookingCoverageId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_BusinessAddressId",
                table: "Clients",
                column: "BusinessAddressId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_ClusterId",
                table: "Clients",
                column: "ClusterId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_FixedDiscountId",
                table: "Clients",
                column: "FixedDiscountId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_ModifiedBy",
                table: "Clients",
                column: "ModifiedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_OwnersAddressId",
                table: "Clients",
                column: "OwnersAddressId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_PriceModeId",
                table: "Clients",
                column: "PriceModeId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_RequestId",
                table: "Clients",
                column: "RequestId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Clients_StoreTypeId",
                table: "Clients",
                column: "StoreTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Clients_Terms",
                table: "Clients",
                column: "Terms");

            migrationBuilder.CreateIndex(
                name: "IX_Companies_AddedBy",
                table: "Companies",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Departments_AddedBy",
                table: "Departments",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Discounts_AddedBy",
                table: "Discounts",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Expenses_AddedBy",
                table: "Expenses",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Expenses_ClientId",
                table: "Expenses",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_Expenses_ModifiedBy",
                table: "Expenses",
                column: "ModifiedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Expenses_RequestId",
                table: "Expenses",
                column: "RequestId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ExpensesRequests_ExpensesId",
                table: "ExpensesRequests",
                column: "ExpensesId");

            migrationBuilder.CreateIndex(
                name: "IX_ExpensesRequests_OtherExpenseId",
                table: "ExpensesRequests",
                column: "OtherExpenseId");

            migrationBuilder.CreateIndex(
                name: "IX_FreebieItems_FreebieRequestId",
                table: "FreebieItems",
                column: "FreebieRequestId");

            migrationBuilder.CreateIndex(
                name: "IX_FreebieItems_ItemId",
                table: "FreebieItems",
                column: "ItemId");

            migrationBuilder.CreateIndex(
                name: "IX_FreebieRequests_ClientId",
                table: "FreebieRequests",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_FreebieRequests_RequestedBy",
                table: "FreebieRequests",
                column: "RequestedBy");

            migrationBuilder.CreateIndex(
                name: "IX_FreebieRequests_RequestId",
                table: "FreebieRequests",
                column: "RequestId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ItemPriceChanges_PriceModeItemId",
                table: "ItemPriceChanges",
                column: "PriceModeItemId");

            migrationBuilder.CreateIndex(
                name: "IX_Items_AddedBy",
                table: "Items",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Items_MeatTypeId",
                table: "Items",
                column: "MeatTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Items_ProductSubCategoryId",
                table: "Items",
                column: "ProductSubCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Items_UomId",
                table: "Items",
                column: "UomId");

            migrationBuilder.CreateIndex(
                name: "IX_ListingFeeItems_ItemId",
                table: "ListingFeeItems",
                column: "ItemId");

            migrationBuilder.CreateIndex(
                name: "IX_ListingFeeItems_ListingFeeId",
                table: "ListingFeeItems",
                column: "ListingFeeId");

            migrationBuilder.CreateIndex(
                name: "IX_ListingFees_ClientId",
                table: "ListingFees",
                column: "ClientId");

            migrationBuilder.CreateIndex(
                name: "IX_ListingFees_RequestedBy",
                table: "ListingFees",
                column: "RequestedBy");

            migrationBuilder.CreateIndex(
                name: "IX_ListingFees_RequestId",
                table: "ListingFees",
                column: "RequestId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Locations_AddedBy",
                table: "Locations",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MeatTypes_AddedBy",
                table: "MeatTypes",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ModeOfPayments_AddedBy",
                table: "ModeOfPayments",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Notifications_UserId",
                table: "Notifications",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_OtherExpenses_AddedBy",
                table: "OtherExpenses",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_PriceMode_AddedBy",
                table: "PriceMode",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_PriceMode_ModifiedBy",
                table: "PriceMode",
                column: "ModifiedBy");

            migrationBuilder.CreateIndex(
                name: "IX_PriceModeItems_AddedBy",
                table: "PriceModeItems",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_PriceModeItems_ItemId",
                table: "PriceModeItems",
                column: "ItemId");

            migrationBuilder.CreateIndex(
                name: "IX_PriceModeItems_ModifiedBy",
                table: "PriceModeItems",
                column: "ModifiedBy");

            migrationBuilder.CreateIndex(
                name: "IX_PriceModeItems_PriceModeId",
                table: "PriceModeItems",
                column: "PriceModeId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductCategories_AddedBy",
                table: "ProductCategories",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProductSubCategories_AddedBy",
                table: "ProductSubCategories",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ProductSubCategories_ProductCategoryId",
                table: "ProductSubCategories",
                column: "ProductCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_RequestApprovers_ApproverId",
                table: "RequestApprovers",
                column: "ApproverId");

            migrationBuilder.CreateIndex(
                name: "IX_RequestApprovers_RequestId",
                table: "RequestApprovers",
                column: "RequestId");

            migrationBuilder.CreateIndex(
                name: "IX_Requests_CurrentApproverId",
                table: "Requests",
                column: "CurrentApproverId");

            migrationBuilder.CreateIndex(
                name: "IX_Requests_RequestorId",
                table: "Requests",
                column: "RequestorId");

            migrationBuilder.CreateIndex(
                name: "IX_StoreTypes_AddedBy",
                table: "StoreTypes",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_StoreTypes_ModifiedBy",
                table: "StoreTypes",
                column: "ModifiedBy");

            migrationBuilder.CreateIndex(
                name: "IX_TermDays_AddedBy",
                table: "TermDays",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TermOptions_AddedBy",
                table: "TermOptions",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_TermOptions_ClientsId",
                table: "TermOptions",
                column: "ClientsId");

            migrationBuilder.CreateIndex(
                name: "IX_TermOptions_TermDaysId",
                table: "TermOptions",
                column: "TermDaysId");

            migrationBuilder.CreateIndex(
                name: "IX_TermOptions_TermsId",
                table: "TermOptions",
                column: "TermsId");

            migrationBuilder.CreateIndex(
                name: "IX_Terms_AddedBy",
                table: "Terms",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Uoms_AddedBy",
                table: "Uoms",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UpdateRequestTrails_RequestId",
                table: "UpdateRequestTrails",
                column: "RequestId");

            migrationBuilder.CreateIndex(
                name: "IX_UserRoles_AddedBy",
                table: "UserRoles",
                column: "AddedBy");

            migrationBuilder.CreateIndex(
                name: "IX_Users_AddedBy",
                table: "Users",
                column: "AddedBy",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_CompanyId",
                table: "Users",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_DepartmentId",
                table: "Users",
                column: "DepartmentId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_LocationId",
                table: "Users",
                column: "LocationId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_UserRolesId",
                table: "Users",
                column: "UserRolesId");

            migrationBuilder.AddForeignKey(
                name: "FK_Approval_Requests_RequestId",
                table: "Approval",
                column: "RequestId",
                principalTable: "Requests",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Approval_Users_ApproverId",
                table: "Approval",
                column: "ApproverId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Approvers_Users_UserId",
                table: "Approvers",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_BookingCoverages_Users_AddedBy",
                table: "BookingCoverages",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_CdoClusters_Users_UserId",
                table: "CdoClusters",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ClientDocuments_Clients_ClientId",
                table: "ClientDocuments",
                column: "ClientId",
                principalTable: "Clients",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ClientModeOfPayments_Clients_ClientId",
                table: "ClientModeOfPayments",
                column: "ClientId",
                principalTable: "Clients",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ClientModeOfPayments_ModeOfPayments_ModeOfPaymentId",
                table: "ClientModeOfPayments",
                column: "ModeOfPaymentId",
                principalTable: "ModeOfPayments",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Clients_PriceMode_PriceModeId",
                table: "Clients",
                column: "PriceModeId",
                principalTable: "PriceMode",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Clients_Requests_RequestId",
                table: "Clients",
                column: "RequestId",
                principalTable: "Requests",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Clients_StoreTypes_StoreTypeId",
                table: "Clients",
                column: "StoreTypeId",
                principalTable: "StoreTypes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Clients_TermOptions_Terms",
                table: "Clients",
                column: "Terms",
                principalTable: "TermOptions",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Clients_Users_AddedBy",
                table: "Clients",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Clients_Users_ModifiedBy",
                table: "Clients",
                column: "ModifiedBy",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Companies_Users_AddedBy",
                table: "Companies",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Departments_Users_AddedBy",
                table: "Departments",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Discounts_Users_AddedBy",
                table: "Discounts",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Expenses_Requests_RequestId",
                table: "Expenses",
                column: "RequestId",
                principalTable: "Requests",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Expenses_Users_AddedBy",
                table: "Expenses",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Expenses_Users_ModifiedBy",
                table: "Expenses",
                column: "ModifiedBy",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ExpensesRequests_OtherExpenses_OtherExpenseId",
                table: "ExpensesRequests",
                column: "OtherExpenseId",
                principalTable: "OtherExpenses",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_FreebieItems_FreebieRequests_FreebieRequestId",
                table: "FreebieItems",
                column: "FreebieRequestId",
                principalTable: "FreebieRequests",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_FreebieItems_Items_ItemId",
                table: "FreebieItems",
                column: "ItemId",
                principalTable: "Items",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_FreebieRequests_Requests_RequestId",
                table: "FreebieRequests",
                column: "RequestId",
                principalTable: "Requests",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_FreebieRequests_Users_RequestedBy",
                table: "FreebieRequests",
                column: "RequestedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ItemPriceChanges_PriceModeItems_PriceModeItemId",
                table: "ItemPriceChanges",
                column: "PriceModeItemId",
                principalTable: "PriceModeItems",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Items_MeatTypes_MeatTypeId",
                table: "Items",
                column: "MeatTypeId",
                principalTable: "MeatTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Items_ProductSubCategories_ProductSubCategoryId",
                table: "Items",
                column: "ProductSubCategoryId",
                principalTable: "ProductSubCategories",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Items_Uoms_UomId",
                table: "Items",
                column: "UomId",
                principalTable: "Uoms",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Items_Users_AddedBy",
                table: "Items",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ListingFeeItems_ListingFees_ListingFeeId",
                table: "ListingFeeItems",
                column: "ListingFeeId",
                principalTable: "ListingFees",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ListingFees_Requests_RequestId",
                table: "ListingFees",
                column: "RequestId",
                principalTable: "Requests",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ListingFees_Users_RequestedBy",
                table: "ListingFees",
                column: "RequestedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Locations_Users_AddedBy",
                table: "Locations",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_MeatTypes_Users_AddedBy",
                table: "MeatTypes",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ModeOfPayments_Users_AddedBy",
                table: "ModeOfPayments",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Notifications_Users_UserId",
                table: "Notifications",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_OtherExpenses_Users_AddedBy",
                table: "OtherExpenses",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_PriceMode_Users_AddedBy",
                table: "PriceMode",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_PriceMode_Users_ModifiedBy",
                table: "PriceMode",
                column: "ModifiedBy",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_PriceModeItems_Users_AddedBy",
                table: "PriceModeItems",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_PriceModeItems_Users_ModifiedBy",
                table: "PriceModeItems",
                column: "ModifiedBy",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ProductCategories_Users_AddedBy",
                table: "ProductCategories",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_ProductSubCategories_Users_AddedBy",
                table: "ProductSubCategories",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_RequestApprovers_Requests_RequestId",
                table: "RequestApprovers",
                column: "RequestId",
                principalTable: "Requests",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_RequestApprovers_Users_ApproverId",
                table: "RequestApprovers",
                column: "ApproverId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_Users_CurrentApproverId",
                table: "Requests",
                column: "CurrentApproverId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_Users_RequestorId",
                table: "Requests",
                column: "RequestorId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_StoreTypes_Users_AddedBy",
                table: "StoreTypes",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_StoreTypes_Users_ModifiedBy",
                table: "StoreTypes",
                column: "ModifiedBy",
                principalTable: "Users",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_TermDays_Users_AddedBy",
                table: "TermDays",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_TermOptions_Terms_TermsId",
                table: "TermOptions",
                column: "TermsId",
                principalTable: "Terms",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_TermOptions_Users_AddedBy",
                table: "TermOptions",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Terms_Users_AddedBy",
                table: "Terms",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_Uoms_Users_AddedBy",
                table: "Uoms",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);

            migrationBuilder.AddForeignKey(
                name: "FK_UserRoles_Users_AddedBy",
                table: "UserRoles",
                column: "AddedBy",
                principalTable: "Users",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Clients_Requests_RequestId",
                table: "Clients");

            migrationBuilder.DropForeignKey(
                name: "FK_BookingCoverages_Users_AddedBy",
                table: "BookingCoverages");

            migrationBuilder.DropForeignKey(
                name: "FK_Clients_Users_AddedBy",
                table: "Clients");

            migrationBuilder.DropForeignKey(
                name: "FK_Clients_Users_ModifiedBy",
                table: "Clients");

            migrationBuilder.DropForeignKey(
                name: "FK_Companies_Users_AddedBy",
                table: "Companies");

            migrationBuilder.DropForeignKey(
                name: "FK_Departments_Users_AddedBy",
                table: "Departments");

            migrationBuilder.DropForeignKey(
                name: "FK_Locations_Users_AddedBy",
                table: "Locations");

            migrationBuilder.DropForeignKey(
                name: "FK_PriceMode_Users_AddedBy",
                table: "PriceMode");

            migrationBuilder.DropForeignKey(
                name: "FK_PriceMode_Users_ModifiedBy",
                table: "PriceMode");

            migrationBuilder.DropForeignKey(
                name: "FK_StoreTypes_Users_AddedBy",
                table: "StoreTypes");

            migrationBuilder.DropForeignKey(
                name: "FK_StoreTypes_Users_ModifiedBy",
                table: "StoreTypes");

            migrationBuilder.DropForeignKey(
                name: "FK_TermDays_Users_AddedBy",
                table: "TermDays");

            migrationBuilder.DropForeignKey(
                name: "FK_TermOptions_Users_AddedBy",
                table: "TermOptions");

            migrationBuilder.DropForeignKey(
                name: "FK_Terms_Users_AddedBy",
                table: "Terms");

            migrationBuilder.DropForeignKey(
                name: "FK_UserRoles_Users_AddedBy",
                table: "UserRoles");

            migrationBuilder.DropForeignKey(
                name: "FK_Clients_Clusters_ClusterId",
                table: "Clients");

            migrationBuilder.DropForeignKey(
                name: "FK_TermOptions_Clients_ClientsId",
                table: "TermOptions");

            migrationBuilder.DropTable(
                name: "Approval");

            migrationBuilder.DropTable(
                name: "Approvers");

            migrationBuilder.DropTable(
                name: "CdoClusters");

            migrationBuilder.DropTable(
                name: "ClientDocuments");

            migrationBuilder.DropTable(
                name: "ClientModeOfPayments");

            migrationBuilder.DropTable(
                name: "Discounts");

            migrationBuilder.DropTable(
                name: "ExpensesRequests");

            migrationBuilder.DropTable(
                name: "FreebieItems");

            migrationBuilder.DropTable(
                name: "ItemPriceChanges");

            migrationBuilder.DropTable(
                name: "ListingFeeItems");

            migrationBuilder.DropTable(
                name: "Notifications");

            migrationBuilder.DropTable(
                name: "RequestApprovers");

            migrationBuilder.DropTable(
                name: "UpdateRequestTrails");

            migrationBuilder.DropTable(
                name: "VariableDiscounts");

            migrationBuilder.DropTable(
                name: "ModeOfPayments");

            migrationBuilder.DropTable(
                name: "Expenses");

            migrationBuilder.DropTable(
                name: "OtherExpenses");

            migrationBuilder.DropTable(
                name: "FreebieRequests");

            migrationBuilder.DropTable(
                name: "PriceModeItems");

            migrationBuilder.DropTable(
                name: "ListingFees");

            migrationBuilder.DropTable(
                name: "Items");

            migrationBuilder.DropTable(
                name: "MeatTypes");

            migrationBuilder.DropTable(
                name: "ProductSubCategories");

            migrationBuilder.DropTable(
                name: "Uoms");

            migrationBuilder.DropTable(
                name: "ProductCategories");

            migrationBuilder.DropTable(
                name: "Requests");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Companies");

            migrationBuilder.DropTable(
                name: "Departments");

            migrationBuilder.DropTable(
                name: "Locations");

            migrationBuilder.DropTable(
                name: "UserRoles");

            migrationBuilder.DropTable(
                name: "Clusters");

            migrationBuilder.DropTable(
                name: "Clients");

            migrationBuilder.DropTable(
                name: "Address");

            migrationBuilder.DropTable(
                name: "BookingCoverages");

            migrationBuilder.DropTable(
                name: "BusinessAddress");

            migrationBuilder.DropTable(
                name: "FixedDiscounts");

            migrationBuilder.DropTable(
                name: "PriceMode");

            migrationBuilder.DropTable(
                name: "StoreTypes");

            migrationBuilder.DropTable(
                name: "TermOptions");

            migrationBuilder.DropTable(
                name: "TermDays");

            migrationBuilder.DropTable(
                name: "Terms");

            migrationBuilder.DropSequence(
                name: "arcana_hilo_sequence");
        }
    }
}
